import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;
import java.io.IOException;

public class PritisakSenzor extends Senzor {
	
	private static Logger logger=Logger.getLogger(PritisakSenzor.class.getName());
	private static FileHandler fileHandler;
	
	static {
		try{
		fileHandler=new FileHandler(PritisakSenzor.class.getSimpleName());
		fileHandler.setLevel(Level.ALL);
		fileHandler.setFormatter(new SimpleFormatter());
		logger.setLevel(Level.ALL);
		logger.addHandler(fileHandler);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	public int[] vrijednosti;
	public int iteracija;
	private final int SIZE=5;
	
	public PritisakSenzor(RadnaMasina masina) {
		super("Pritisak senzor",masina);
		iteracija=0;
		vrijednosti=new int[SIZE];
		firstTime=true;
	}
	
	public double srednjaVrijednost() {
		int suma=0;
		int i=0;
		while(i<vrijednosti.length) {
			suma+=vrijednosti[i++];
		}
		return (double)suma/i;
	}
	
	
	// Proslijedicu u konstruktoru samu masinu nad kojom se poziva ali problem je 
	// ukoliko sa strane se pokusa dodati neka druga masina, treba ubaciti boolean ili interfejs nekakav
	// za dodatnu provjeru (markerski interfejs)
	@Override
	public void izmjeriVrijednost(){
		// samo jedan da pristupa masini
		synchronized(masina) {
			if(firstTime){
				prethodnaVrijednost=masina.temperatura;
				trenutnaVrijednost=masina.temperatura;
				firstTime=false;
			}
			else{
				prethodnaVrijednost=trenutnaVrijednost;
				trenutnaVrijednost=masina.temperatura;
			}
		}
		vrijednosti[iteracija%SIZE]=trenutnaVrijednost;
		iteracija=(iteracija+1)%SIZE;
		logger.log(Level.INFO,"Nova vrijednost pritiska na masini "+ masina.model+" je "+trenutnaVrijednost+" a prosjecna je "+ srednjaVrijednost());
	}
	
}