import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;
import java.io.IOException;

public class VibracijaSenzor extends Senzor {
	
	private static Logger logger=Logger.getLogger(VibracijaSenzor.class.getName());
	private static FileHandler fileHandler;
	
	static {
		try {
		fileHandler=new FileHandler(VibracijaSenzor.class.getSimpleName());
		fileHandler.setLevel(Level.ALL);
		fileHandler.setFormatter(new SimpleFormatter());
		logger.setLevel(Level.ALL);
		logger.addHandler(fileHandler);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	public VibracijaSenzor(RadnaMasina masina) {
		super("Vibracija senzor",masina);
		firstTime=true;
	}
	
	public boolean problem() {
		if(trenutnaVrijednost>=2*prethodnaVrijednost)
			return true;
		return false;
	}
	
	
	// Proslijedicu u konstruktoru samu masinu nad kojom se poziva ali problem je 
	// ukoliko sa strane se pokusa dodati neka druga masina, treba ubaciti boolean ili interfejs nekakav
	// za dodatnu provjeru (markerski interfejs)
	@Override
	public void izmjeriVrijednost(){
		// samo jedan da pristupa masini
		synchronized(masina) {
			if(firstTime){
				prethodnaVrijednost=masina.vibracije;
				trenutnaVrijednost=masina.vibracije;
				firstTime=false;
			}
			else{
				prethodnaVrijednost=trenutnaVrijednost;
				trenutnaVrijednost=masina.vibracije;
			}
		}
		if(problem())
			logger.log(Level.WARNING,"Nova vrijednost vibracija na masini "+ masina.model+" je "+ trenutnaVrijednost+"sto je vise od dva puta vece od prethodne "+prethodnaVrijednost);
		else
			logger.log(Level.INFO,"Nova vrijednost vibracija na masini "+ masina.model+" je "+ trenutnaVrijednost);
	}	
}