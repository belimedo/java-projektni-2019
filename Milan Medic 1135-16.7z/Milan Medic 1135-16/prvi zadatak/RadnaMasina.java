import java.util.List;
import java.util.Random;

public class RadnaMasina extends Thread {
	
	private static int counter;
	static {
		counter=0;
	}
	
	public boolean status; //true=on, false=off
	public final int id;
	public String model;
	public List<Senzor> senzori;
	
	public int temperatura;
	public int vlaga;
	public int pritisak;
	public int vibracije;
	
	public void ukljuciMasinu() {
		status=true;
	}
	
	public void iskljuciMasinu() {
		status=false;
	}
	
	
	public RadnaMasina(String model) {
		id=counter++;
		this.model=model;
	}
	
	//TODO: Uraditi generisanje promjenljivih i sleep
	
	@Override 
	public void run() {
		//kada je startam, odmah je ukljucujem,
		ukljuciMasinu();
		//pokrenuli sve senzore
			for(Senzor s:senzori) {
				s.start();
			}
		Random rand=new Random();
		while(status) {
			temperatura=rand.nextInt(20);
			vlaga=rand.nextInt(20);
			pritisak=rand.nextInt(20);
			vibracije=rand.nextInt(50);
			System.out.println("Masina "+model+" radi.");
			try{
				sleep(1000);
			}catch (InterruptedException ex) {
				ex.printStackTrace();
			}
		}
		try {
			for(Senzor s:senzori)
				s.join();
		}catch(InterruptedException ex) {
			ex.printStackTrace();
		}
		System.out.println("Masina "+model+" je prestala sa radom.");
		
		
	}
	
}