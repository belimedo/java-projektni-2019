

public abstract class Senzor extends Thread {
	
	public int prethodnaVrijednost;
	public int trenutnaVrijednost;
	public String naziv;
	public abstract void izmjeriVrijednost();
	protected boolean firstTime;
	
	protected Senzor(String naziv, RadnaMasina masina) {
		this.naziv=naziv;
		this.masina=masina;
	}
	protected RadnaMasina masina;
	
	@Override
	public void run() {
		while(masina.status){
			try {
				izmjeriVrijednost();
				sleep(500);
			}catch(InterruptedException ex) {
				ex.printStackTrace();
			}
		}
		System.out.println("Senzor "+naziv + "je zavrsio sa radom.");
	}
	
	
}