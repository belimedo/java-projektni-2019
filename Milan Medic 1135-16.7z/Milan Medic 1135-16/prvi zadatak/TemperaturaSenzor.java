import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;
import java.io.IOException;

public class TemperaturaSenzor extends Senzor {
	
	private static Logger logger=Logger.getLogger(TemperaturaSenzor.class.getName());
	private static FileHandler fileHandler;
	
	static {
		try{
		fileHandler=new FileHandler(TemperaturaSenzor.class.getSimpleName());
		fileHandler.setLevel(Level.ALL);
		fileHandler.setFormatter(new SimpleFormatter());
		logger.setLevel(Level.ALL);
		logger.addHandler(fileHandler);
		}catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	public int[] vrijednosti;
	public int iteracija;
	private final int SIZE=10;
	
	public TemperaturaSenzor(RadnaMasina masina) {
		super("Temperaturni senzor",masina);
		iteracija=0;
		vrijednosti=new int[SIZE];
		firstTime=true;
	}
	
	
	// Proslijedicu u konstruktoru samu masinu nad kojom se poziva ali problem je 
	// ukoliko sa strane se pokusa dodati neka druga masina, treba ubaciti boolean ili interfejs nekakav
	// za dodatnu provjeru (markerski interfejs)
	@Override
	public void izmjeriVrijednost(){
		// samo jedan da pristupa masini
		synchronized(masina) {
			if(firstTime){
				prethodnaVrijednost=masina.temperatura;
				trenutnaVrijednost=masina.temperatura;
				firstTime=false;
			}
			else{
				prethodnaVrijednost=trenutnaVrijednost;
				trenutnaVrijednost=masina.temperatura;
			}
		}
		vrijednosti[iteracija%SIZE]=trenutnaVrijednost;
		iteracija=(iteracija+1)%SIZE;
		logger.log(Level.INFO,"Nova vrijednost temperature na masini "+ masina.model+" je "+ trenutnaVrijednost+" a prethodna "+prethodnaVrijednost);
	}
	
	
}