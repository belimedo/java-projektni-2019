import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class JavaFabrika {
	
	public static void main(String[] args) {
		RadnaMasina varenje=new RadnaMasina("Masina za varenje");
		RadnaMasina sjecenje=new RadnaMasina("Masina za sjecenje");
		List<Senzor>  varenjeSenzori= new ArrayList<>();
		varenjeSenzori.add(new PritisakSenzor(varenje));
		varenjeSenzori.add(new TemperaturaSenzor(varenje));
		List<Senzor>  sjecenjeSenzori= new ArrayList<>();
		sjecenjeSenzori.add(new VibracijaSenzor(sjecenje));
		sjecenjeSenzori.add(new TemperaturaSenzor(sjecenje));
		sjecenjeSenzori.add(new VlagaSenzor(sjecenje));
		varenje.senzori=varenjeSenzori;
		sjecenje.senzori=sjecenjeSenzori;
		varenje.start();
		sjecenje.start();
		String line;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Da zaustavite rad simulacije unesite STOP");
		do {
			line=scanner.nextLine();
		}while(!"STOP".equals(line));
		varenje.iskljuciMasinu();
		sjecenje.iskljuciMasinu();
		//Ovo ispod je samo jednostavnije za testiranje
		/*try {
			Thread.sleep(5000);
		} catch(InterruptedException ex) {
			ex.printStackTrace();
		}
		varenje.iskljuciMasinu();
		try {
			Thread.sleep(5000);
		} catch(InterruptedException ex) {
			ex.printStackTrace();
		}
		sjecenje.iskljuciMasinu();*/
		
	}
	
}