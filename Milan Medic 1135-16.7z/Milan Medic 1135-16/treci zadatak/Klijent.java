

public class Klijent {
	
	public String ime;
	public String prezime;
	public String id;
	public int stedniIznos;
	
	public Klijent(){
	}
	
	public Klijent(String ime,String prezime,String id,int stedniIznos) {
		this.ime=ime;
		this.prezime=prezime;
		this.id=id;
		this.stedniIznos=stedniIznos;
	}
	
	@Override
	public String toString(){
		return ime+" "+prezime+" "+id+" "+stedniIznos;
	}
	
}