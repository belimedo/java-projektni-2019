import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Calendar;
import java.util.Collections;


public class JavaBank {

	public static void main(String[] args) {
		Calendar cal=Calendar.getInstance();
		List<Klijent> klijenti = new ArrayList<>();
		Random rand=new Random();
		for(int i=0;i<2000;i++){
			klijenti.add(new Klijent("A"+Integer.toString(rand,nextInt(50)),"B"+Integer.toString(rand,nextInt(50)),
			Integer.toString(i)+"-"+cal.YEAR,rand.nextInt(29000)+1000));
		}
		Klijent a=Collections.max(klijenti,(a,b)-> {
			if(a.stedniIznos>b.stedniIznos)
				return 1;
			if(a.stedniIznos<b.stedniIznos)
				return -1;
			return 0;
		});
		klijenti.remove(a);
		Klijent b=Collections.max(klijenti,(a,b)-> {
			if(a.stedniIznos>b.stedniIznos)
				return 1;
			if(a.stedniIznos<b.stedniIznos)
				return -1;
			return 0;
		});
		System.out.println(a +" a drugi je "+ b);
	}

}