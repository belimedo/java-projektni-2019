

public class Komponenta extends Artikl {

	public Komponenta(String naziv,String barkod, String opis){
		super(barkod,naziv,opis);
	}

}