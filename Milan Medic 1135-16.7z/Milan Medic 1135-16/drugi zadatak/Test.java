import java.util.HashMap;
import java.io.*;
import java.util.Scanner;
import java.util.List;

public class Test {
	
	public static void main(String[] args) {
		
		HashMap<String,Baza<Artikl>> prodavnice=new HashMap<>();
		try(BufferedReader in=new BufferedReader(new FileReader("artikli.csv"))) {
			String line;
			String[] prop;
			while((line=in.readLine())!=null) {
				Baza<Artikl> tmp;
				prop=line.split(",");
				if(prop[1].equals("naziv"))
					continue;
				// Ako postoji dodaj samo novi artikl u bazu
				if(prodavnice.containsKey(prop[0])){
					tmp=prodavnice.get(prop[0]);
					if(prop[4].equals("h")){
						tmp.addElementToList(new Hrana(prop[1],prop[2],prop[3]));
					}
					if(prop[4].equals("b")){
						tmp.addElementToList(new BijelaTehnika(prop[1],prop[2],prop[3]));					
					}
					if(prop[4].equals("k")){
						tmp.addElementToList(new Komponenta(prop[1],prop[2],prop[3]));
					}
					prodavnice.replace(prop[0],tmp);
				}
				// ako ne postoji, dodaj novu prodavnicu i bazu sa artiklom
				else{
					tmp=new Baza<Artikl>();
					if(prop[4].equals("h")){
						tmp.addElementToList(new Hrana(prop[1],prop[2],prop[3]));
					}
					if(prop[4].equals("b")){
						tmp.addElementToList(new BijelaTehnika(prop[1],prop[2],prop[3]));					
					}
					if(prop[4].equals("k")){
						tmp.addElementToList(new Komponenta(prop[1],prop[2],prop[3]));
					}
					prodavnice.put(prop[0],tmp);
				}
			}
		}catch(IOException ex) {
			ex.printStackTrace();
		}
		Scanner scanner=new Scanner(System.in);
		String prodavnica;
		String barkod;
		System.out.println("Unesite naziv prodavnice");
		do{
			prodavnica=scanner.nextLine();
		}while(!prodavnice.containsKey(prodavnica));
		Baza<Artikl> dobijena=prodavnice.get(prodavnica);
		System.out.println("Unesite sada barkod");
		barkod=scanner.nextLine();
		List<Artikl> lista=dobijena.pretrazi(barkod); //ovo mogu i gore odmah
		for(Artikl a:lista) {
			System.out.println(a);
		}
		
		
		
		
		
	}

}