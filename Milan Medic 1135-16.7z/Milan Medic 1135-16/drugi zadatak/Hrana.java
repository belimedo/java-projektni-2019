
public class Hrana extends Artikl {

	public Hrana(String naziv,String barkod, String opis){
		super(barkod,naziv,opis);
	}

}