public class BijelaTehnika extends Artikl {

	public BijelaTehnika(String naziv,String barkod, String opis){
		super(barkod,naziv,opis);
	}

}