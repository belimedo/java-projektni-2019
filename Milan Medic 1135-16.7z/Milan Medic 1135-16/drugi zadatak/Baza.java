import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;


public class Baza<T extends Artikl> { 
	
	private List<T> lista;
	
	public Baza() {
		lista=new ArrayList<>();
	}
	
	public List<T> pretrazi(String upit) {
		List<T> pomocnaLista= new ArrayList<>();
		for(T proizvod: lista) {
			if(proizvod.barkod.startsWith(upit))
				pomocnaLista.add(proizvod);
		}
		return pomocnaLista;
	}
	
	public void addElementToList(T element) {
		lista.add(element);
	}
	
	public void deleteElement(T element) {
		lista.remove(element);
	}
	
	public void deleteElementBarkod(String barkod) {
		for(T proizvod :lista) {
			if(proizvod.barkod.equals(barkod))
				lista.remove(proizvod);
		}
	}
	
	public T getElementFromList(String naziv) {
		for(T proizvod: lista) {
			if(proizvod.naziv.equals(naziv))
				return proizvod;
		}
		return null;
	}
	
	public Iterator<T> getInterator() {
		return lista.iterator();
	}
	
	
	
	
	
}