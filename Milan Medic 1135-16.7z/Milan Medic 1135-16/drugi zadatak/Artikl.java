
public abstract class Artikl {
	
	public String barkod;
	public String naziv;
	public String opis;
	
	protected Artikl(String barkod,String naziv, String opis) {
		this.barkod=barkod;
		this.naziv=naziv;
		this.opis=opis;
	}
	
	protected Artikl(){}
	
	@Override
	public String toString(){
		return naziv+" "+barkod+" "+opis;
	}
} 